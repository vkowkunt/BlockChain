/*
 *servlet to do the appropriate client requested methods
 */
/**
 *
 * @author venky
 */
package server;

import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "Project3Task3Server", urlPatterns = {"/Project3Task3Server/*"})
public class Project3Task3Server extends HttpServlet {

    static List<Block> Myblock = new ArrayList<Block>();
    static String ChainHash;
    static int i;
    static String blockchainJson = "";
    java.util.Date today = new java.util.Date();
    java.sql.Timestamp ts1 = new java.sql.Timestamp(today.getTime());
    long tsTime1 = ts1.getTime();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (Myblock.isEmpty()) {
            Block B = new Block(0, tsTime1, "Genesis", 2);
            ChainHash = B.calculateHash();
            Myblock.add(B);
            Myblock.get(B.getIndex()).proofOfWork(2);
            blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
        }
        System.out.println("Console: doGET visited");

        String result = "true";

        String message = (request.getPathInfo());

        for (int i = 0; i < Myblock.size(); i++) {
            Block CurrentBlock = Myblock.get(i);
            String hash = CurrentBlock.calculateHash();
            int difficulty = CurrentBlock.getDifficulty();
            String target = new String(new char[CurrentBlock.difficulty]).replace('\0', '0');

            if (!hash.substring(0, difficulty).equals(target)) {
                System.out.println("Improper hash at node " + i + " does not begin with " + target);
                result = "false";

            }
            if (i == Myblock.size() - 1) {
                if (!hash.equals(ChainHash)) {
                    System.out.println("Improper hash at node " + i + " does not begin with " + target);
                    result = "false";
                }
            } else {
                if (!hash.equals(Myblock.get(i + 1).getPreviousHash())) {
                    System.out.println("Improper hash at node " + i + " does not begin with " + target);
                    result = "false";
                }
            }
        }

        PrintWriter out = response.getWriter();
        out.println(result);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (Myblock.isEmpty()) {
            Block B = new Block(0, tsTime1, "Genesis", 2);
            ChainHash = B.calculateHash();
            Myblock.add(B);
            Myblock.get(B.getIndex()).proofOfWork(2);
            blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
        }
        String viewchain = "{Chain: " + blockchainJson + "ChainHash: " + ChainHash + "}";
        System.out.println(viewchain);
        PrintWriter out = response.getWriter();
        out.println(viewchain);

    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (Myblock.isEmpty()) {
            Block B = new Block(0, tsTime1, "Genesis", 2);
            ChainHash = B.calculateHash();
            Myblock.add(B);
            Myblock.get(B.getIndex()).proofOfWork(2);
            blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
        }

        try {
            System.out.println("Console: doPut visited");

            BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
            String data = br.readLine();
            String[] datasplit = data.split(",");
            String txdata = datasplit[0];
            String difficulty = datasplit[1];

            Block B;
            System.out.println("I was here");
            String wrong = "worked";

            BigInteger e = new BigInteger("65537");
            BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
            System.out.println(txdata);
            String[] splitstring = txdata.split("#");
            String msg = splitstring[0];
            String hashmsg = splitstring[1];
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(msg.getBytes(StandardCharsets.UTF_8));
            System.out.println(hash);
            byte[] hash1 = new byte[hash.length + 1];
            hash1[0] = 0;
            System.arraycopy(hash, 0, hash1, 1, hash.length);
            BigInteger k = new BigInteger(hashmsg);
            BigInteger Decryptmsg = k.modPow(e, n);
            BigInteger hashed = new BigInteger(hash1);
            System.out.println(hash1);
            System.out.println(Decryptmsg);
            if (!hashed.equals(Decryptmsg)) {
                wrong = "signature invalid";
                System.out.println(wrong);
            } else {

                int index = Myblock.size();
                System.out.println("working");
                B = new Block(index, tsTime1, data, Integer.parseInt(difficulty));
                Myblock.add(B);
                Myblock.get(B.getIndex()).proofOfWork(B.getDifficulty());
                ChainHash = Myblock.get(Myblock.size() - 1).calculateHash();

                blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
                System.out.println(blockchainJson);
            }

        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Project3Task3Server.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
