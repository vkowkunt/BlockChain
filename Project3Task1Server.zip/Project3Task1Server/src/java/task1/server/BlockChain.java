/*
 * This a soap block chain server
 */
package task1.server;

import com.google.gson.GsonBuilder;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author venky
 */
@WebService(serviceName = "BlockChain")
public class BlockChain {

    public static List<Block> Myblock = new ArrayList<Block>(); // list to contain the blocks
    static String ChainHash;
    static int i;
    static String blockchainJson = "";
    java.util.Date today = new java.util.Date();
    java.sql.Timestamp ts1 = new java.sql.Timestamp(today.getTime());
    long tsTime1 = ts1.getTime();

    /**
     * add block method to add blocks
     */
    //
    @WebMethod(operationName = "addBlock")
    public String addBlock(@WebParam(name = "data") String data, @WebParam(name = "difficulty") int difficulty) throws NoSuchAlgorithmException {

        Block B;
        System.out.println("I was here");
        String wrong = "worked";

        BigInteger e = new BigInteger("65537");
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        System.out.println(data);
        String[] splitstring = data.split("#");
        String msg = splitstring[0];
        String hashmsg = splitstring[1];
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(msg.getBytes(StandardCharsets.UTF_8));
        System.out.println(hash);
        byte[] hash1 = new byte[hash.length + 1];
        hash1[0] = 0;
        System.arraycopy(hash, 0, hash1, 1, hash.length);
        BigInteger k = new BigInteger(hashmsg);
        BigInteger Decryptmsg = k.modPow(e, n);
        BigInteger hashed = new BigInteger(hash1);
        System.out.println(hash1);
        System.out.println(Decryptmsg);
        if (!hashed.equals(Decryptmsg)) {
            wrong = "signature invalid";
            System.out.println(wrong);
        } else {
            if (!Myblock.isEmpty()) {
                int index = Myblock.size();
                System.out.println("working");
                B = new Block(index, tsTime1, data, difficulty);
                Myblock.add(B);
                Myblock.get(B.getIndex()).proofOfWork(B.getDifficulty());
                ChainHash = Myblock.get(Myblock.size() - 1).calculateHash();

                blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
            } //loading the block chain into a json fprmat string
        }

        return wrong;

    }

    /**
     * to verify the chain
     */
    // 
    @WebMethod(operationName = "isChainValid")
    public boolean isChainValid() {

        for (int i = 0; i < Myblock.size(); i++) {
            Block CurrentBlock = Myblock.get(i);
            String hash = CurrentBlock.calculateHash();
            int difficulty = CurrentBlock.getDifficulty();
            String target = new String(new char[CurrentBlock.difficulty]).replace('\0', '0');

            if (!hash.substring(0, difficulty).equals(target)) {
                System.out.println("Improper hash at node " + i + " does not begin with " + target);
                return false;
            }
            if (i == Myblock.size() - 1) {
                if (!hash.equals(ChainHash)) {
                    System.out.println("Improper hash at node " + i + " does not begin with " + target);
                    return false;
                }
            } else {
                if (!hash.equals(Myblock.get(i + 1).getPreviousHash())) {
                    System.out.println("Improper hash at node " + i + " does not begin with " + target);
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * to view the chain
     */
    //
    @WebMethod(operationName = "viewChain")
    public String viewChain() {

        //TODO write your implementation code here:
        return "{'Chain':" + blockchainJson + " 'ChainHash':" + ChainHash + "}";
    }

    /**
     * genesis block creator
     */
    @WebMethod(operationName = "zeroBlock")
    @Oneway

    public void zeroBlock() {
        Block B = new Block(0, tsTime1, "Genesis", 2);
        ChainHash = B.calculateHash();
        Myblock.add(B);
        Myblock.get(B.getIndex()).proofOfWork(2);
        blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
    }

}
