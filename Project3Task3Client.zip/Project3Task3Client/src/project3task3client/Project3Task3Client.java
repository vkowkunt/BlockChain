/*
 * Client which uses httpURL to add block to the block chain
 */
package project3task3client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/**
 *
 * @author venky
 */
public class Project3Task3Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NoSuchAlgorithmException {

        Scanner in = new Scanner(System.in);

        Boolean flag = true;
        while (flag == true) {
            System.out.println("1. Add a transaction to the blockchain");
            System.out.println("2. Verify the blockchain");
            System.out.println("3. View the blockchain");
            System.out.println("4. exit");
            int input = in.nextInt();
            if (input == 1) {

                Scanner integer = new Scanner(System.in);
                System.out.println("Enter Difficulty");
                int difficulty = integer.nextInt();
                System.out.println("Enter Transaction");
                Scanner transaction = new Scanner(System.in);
                String tx = transaction.nextLine();

                BigInteger e = new BigInteger("65537");
                BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
                BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");

                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hash = digest.digest(tx.getBytes(StandardCharsets.UTF_8));

                byte[] hash1 = new byte[hash.length + 1];
                hash1[0] = 0;
                System.arraycopy(hash, 0, hash1, 1, hash.length);

                BigInteger data = new BigInteger(hash1);
                BigInteger encrypted_data = data.modPow(d, n);

                String message = tx + "#" + encrypted_data;
                long starttime = System.currentTimeMillis();
                addBlock(message, difficulty);   //add block method calling
                long endtime = System.currentTimeMillis();
                System.out.println("Total Execution Time to add this block is " + (endtime - starttime) + " milliseconds");
            }
            if (input == 2) {
                long starttime = System.currentTimeMillis();
                System.out.println("Verifying");
                System.out.println("Chain Verification: " + isChainValid()); // invoking verify chain method
                long endtime = System.currentTimeMillis();
                System.out.println("Total Execution Time to verify this Chain is " + (endtime - starttime) + " milliseconds");
            }
            if (input == 3) {
                System.out.println(viewChain()); // viewing the chain
            }
            if (input == 4) {
                flag = false; // exit
            }
        }

    }

    private static void addBlock(java.lang.String data, int difficulty) {
        doPut(data, difficulty);

    }

    private static String isChainValid() {
        String answer = doGet();
        return answer;
    }

    private static String viewChain() {
        return doPost();

    }

    // do put to add blocks
    public static void doPut(String data, int difficulty) {

        String status;
        String output;

        try {
            // Make call to a particular URL
            URL url = new URL("http://localhost:9090/Project-3task-3Server/Project3Task3Server/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // set request method to POST and send name value pair
            conn.setRequestMethod("PUT");
            conn.setDoOutput(true);
            // write to POST data area
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(data + "," + difficulty);
            out.close();

            // get HTTP response code sent by server
            status = conn.getResponseMessage();

            //close the connection
            conn.disconnect();
        } // handle exceptions
        catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    // do get to verify chain
    public static String doGet() {
        String flag = "true";
        String status = null;
        String output;
        String responseBody = null;

        try {
            // Make call to a particular URL
            URL url = new URL("http://localhost:9090/Project-3task-3Server/Project3Task3Server/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // set request method to POST and send name value pair
            conn.setRequestMethod("GET");
            conn.setDoOutput(true);
            // write to POST data area

            InputStream response = conn.getInputStream();
            try (Scanner scanner = new Scanner(response)) {
                responseBody = scanner.next();
                System.out.println(responseBody);
            }
            //close the connection
            conn.disconnect();
        } // handle exceptions
        catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return responseBody;
    }

    //do get to view the chain
    public static String doPost() {

        String status = null;
        String output;
        String responseBody = null;
        try {
            // Make call to a particular URL
            URL url = new URL("http://localhost:9090/Project-3task-3Server/Project3Task3Server/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // set request method to POST and send name value pair
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "text/xml");
            // write to POST data area

            // get HTTP response code sent by server
            InputStream response = conn.getInputStream();
            Scanner scanner = new Scanner(response);

            responseBody = scanner.useDelimiter("\\A").next();

            //close the connection
            conn.disconnect();
        } // handle exceptions
        catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // return HTTP status
        return responseBody;

    }
}
