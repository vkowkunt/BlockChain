/*
 *Block class with required constructors and getters setters
 */
package project3task0;

/**
 *
 * @author venky
 */
import java.math.BigInteger;

public final class Block {

    public int index;
    public String previousHash;
    public String Data; //a simple message.
    long timestamp;
    public int difficulty;
    public BigInteger nonce = new BigInteger("0");

    public Block(int index, long timestamp, String data, int difficulty) {
        this.index = index;
        this.Data = data;
        this.previousHash = getPreviousHash();
        this.timestamp = timestamp;
        this.difficulty = difficulty;

    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getPreviousHash() {
        if (index > 0) {
            previousHash = BlockChain.Myblock.get(index - 1).calculateHash();
        } else {
            previousHash = "";
        }
        return previousHash;
    }

    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }

    public String getData() {
        return Data;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public BigInteger getNonce() {
        return nonce;
    }

    public void setNonce(BigInteger nonce) {
        this.nonce = nonce;
    }

    public String calculateHash() {
        String calculatedhash = SHA256Hasher.applySha256(
                index
                + timestamp
                + Data
                + previousHash
                + // calculates the hash
                nonce
                + difficulty
        );
        return calculatedhash;
    }

    public String proofOfWork(int difficulty) {
        String hash = calculateHash();
        String target = new String(new char[difficulty]).replace('\0', '0'); //Create a string with difficulty * "0" //https://medium.com/programmers-blockchain/create-simple-blockchain-java-tutorial-from-scratch-6eeed3cb03fa
        while (!hash.substring(0, difficulty).equals(target)) {
            nonce = nonce.add(new BigInteger("1"));
            hash = calculateHash();
        }
        return hash; //this method computes the hash until a suitable hash is found based on the difficulty
    }
}
