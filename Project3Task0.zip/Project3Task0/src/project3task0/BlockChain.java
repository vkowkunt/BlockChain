/*
 * Block chain creator 
 */
package project3task0;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.google.gson.GsonBuilder;

/**
 *
 * @author venky
 */
public class BlockChain {

    public static List<Block> Myblock = new ArrayList<Block>();// list to contain the blocks
    static String ChainHash;
    static int Block_Number;

    public static void main(String[] args) {
        BlockChain blockchain = new BlockChain();
        java.util.Date today = new java.util.Date();
        java.sql.Timestamp ts1 = new java.sql.Timestamp(today.getTime());
        long tsTime1 = ts1.getTime();

        Block newBlock = new Block(0, tsTime1, "Genesis", 2); // Creation of the genesis block
        addBlock(newBlock);
        ChainHash = newBlock.calculateHash();

        Scanner in = new Scanner(System.in);
        Boolean flag = true;
        while (flag == true) {
            String blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock); //loading the block chain into a json fprmat string

            System.out.println("1. Add a transaction to the blockchain");
            System.out.println("2. Verify the blockchain");
            System.out.println("3. View the blockchain");
            System.out.println("4. Corrupt the chain");
            System.out.println("5. Hide the corruption by re-computing hashes");
            System.out.println("6. Exit");
            int input = in.nextInt();

            switch (input) {
                case 1: {
                    //add a block to the chain
                    Block block;
                    System.out.println("Enter difficulty");
                    int difficulty = in.nextInt();
                    System.out.println("Enter Transaction");
                    Scanner transaction = new Scanner(System.in);
                    String tx = transaction.nextLine();
                    block = new Block((Myblock.get(Myblock.size() - 1).getIndex()) + 1, tsTime1, tx, difficulty);
                    long starttime = System.currentTimeMillis();
                    addBlock(block); // invokes add block method
                    ChainHash = Myblock.get(Myblock.size() - 1).calculateHash();
                    long endtime = System.currentTimeMillis();
                    System.out.println("Total Execution Time to add this block " + (endtime - starttime) + " milliseconds");

                    break;
                }
                case 2: {
                    long starttime = System.currentTimeMillis();
                    System.out.println("Verifying");
                    System.out.println("Chain Verification: " + isChainValid()); // verifying the chain
                    long endtime = System.currentTimeMillis();
                    System.out.println("Total Execution Time to verify this Chain is " + (endtime - starttime) + " milliseconds");
                    break;
                }
                case 3:
                    System.out.println("{'Chain':" + blockchainJson + ",'ChainHash': '" + ChainHash + "'}");// viewing the chain
                    break;
                case 4: {
                    Scanner update = new Scanner(System.in);
                    System.out.println("Corrupt the block chain");
                    System.out.println("Enter block to corrupt:");
                    Block_Number = update.nextInt();
                    Scanner transact = new Scanner(System.in);
                    System.out.println("Enter new Data for block " + Block_Number);
                    String transaction = transact.nextLine();
                    Myblock.get(Block_Number).setData(transaction); // corrupting by setting the data
                    System.out.println("Block " + Block_Number + " holds " + transaction);
                    break;
                }
                case 5: {
                    System.out.println("Repair the block chain");
                    repairChain(); // repairing the chain
                    System.out.println("Repair Complete");
                    break;
                }
                case 6:
                    flag = false;
                    break;// to exit
                default:
                    break;
            }

        }

    }

    public static void addBlock(Block B) {
        if (Myblock.isEmpty()) {
            Myblock.add(B);
            Myblock.get(B.getIndex()).proofOfWork(2); // add if blockchain is empty
        } else {
            Myblock.add(B);
            Myblock.get(B.getIndex()).proofOfWork(B.getDifficulty());//add to blockchain

        }
    }

    /* checking if the chain is valid or not */
    public static Boolean isChainValid() {

        for (int i = 0; i < Myblock.size(); i++) {
            Block CurrentBlock = Myblock.get(i);
            String hash = CurrentBlock.calculateHash();
            int difficulty = CurrentBlock.getDifficulty();
            String target = new String(new char[CurrentBlock.difficulty]).replace('\0', '0');

            if (!hash.substring(0, difficulty).equals(target)) {
                System.out.println("Improper hash at node " + i + " does not begin with " + target);
                return false;
            }
            if (i == Myblock.size() - 1) {
                if (!hash.equals(ChainHash)) {
                    System.out.println("Improper hash at node " + i + " does not begin with " + target);
                    return false;
                }
            } else {
                if (!hash.equals(Myblock.get(i + 1).getPreviousHash())) {
                    System.out.println("Improper hash at node " + i + " does not begin with " + target);
                    return false;
                }
            }
        }

        return true;

    }

    /* this method repairs the chain by recomputing the hashes*/
    public static void repairChain() {
        if (Myblock.get(0).calculateHash().equals(Myblock.get(1).previousHash)) {
            Myblock.get(0).proofOfWork(2);
            Myblock.get(1).setPreviousHash(Myblock.get(0).proofOfWork(2));
            Myblock.get(1).proofOfWork(Myblock.get(1).getDifficulty());
            ChainHash = Myblock.get(0).proofOfWork(2);
        }

        for (int i = 1; i < Myblock.size(); i++) {

            if (!Myblock.get(i - 1).calculateHash().equals(Myblock.get(i).previousHash)) {

                Myblock.get(i).setPreviousHash(Myblock.get(i - 1).proofOfWork(Myblock.get(i - 1).getDifficulty()));
                Myblock.get(i).proofOfWork(Myblock.get(i).getDifficulty());
                ChainHash = Myblock.get(i).proofOfWork(Myblock.get(i).getDifficulty());
            }

        }
    }
}
