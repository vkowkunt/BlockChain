/*
 * This class has the method to hash the given string using sha-256 message digest
 */
package project3task0;

import java.security.MessageDigest;

/**
 *
 * @author venky
 */
public class SHA256Hasher{    //https://medium.com/programmers-blockchain/create-simple-blockchain-java-tutorial-from-scratch-6eeed3cb03fa
    
    public static String applySha256(String input){	
        StringBuffer hexString = new StringBuffer(); // This will contain hash as hexidecimal
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");	//Applies sha256 to our input,         
			byte[] hash = digest.digest(input.getBytes("UTF-8"));	         
			for (int i = 0; i < hash.length; i++) {
				String hex = Integer.toHexString(0xff & hash[i]);
				if(hex.length() == 1) hexString.append('0');
				hexString.append(hex);
			}
			
		}
                
		catch(Exception e) {
			                 System.out.println("Hashing failed");
		}
       
        return hexString.toString();
	}	
    
}
