/*
 * Client to send block chain data using a XML string
 */
package project3task1;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import task1.server.IOException_Exception;
import task1.server.NoSuchAlgorithmException_Exception;
import task1.server.ParserConfigurationException_Exception;
import task1.server.SAXException_Exception;

/**
 *
 * @author venky
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException_Exception, ParserConfigurationException_Exception, NoSuchAlgorithmException_Exception, SAXException_Exception {
        // TODO code application logic here

        Scanner in = new Scanner(System.in);
        Boolean flag = true;
        while (flag == true) {
            System.out.println("1. Add a transaction to the blockchain");
            System.out.println("2. Verify the blockchain");
            System.out.println("3. View the blockchain");
            System.out.println("4. exit");
            int input = in.nextInt();
            if (input == 1) { // add block method entry

                Scanner integer = new Scanner(System.in);
                System.out.println("Enter Difficulty");
                int difficulty = integer.nextInt();
                System.out.println("Enter Transaction");
                Scanner transaction = new Scanner(System.in);
                String tx = transaction.nextLine();

                BigInteger e = new BigInteger("65537");
                BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
                BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
                String hashedbytes = SHA256Hasher.applySha256(tx);
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hash = digest.digest(tx.getBytes(StandardCharsets.UTF_8));

                byte[] hash1 = new byte[hash.length + 1];
                hash1[0] = 0;
                System.arraycopy(hash, 0, hash1, 1, hash.length);

                BigInteger data = new BigInteger(hash1);
                BigInteger encrypted_data = data.modPow(d, n);

                String message = tx + "#" + encrypted_data;
                String dataXML = "<newfile><method>addblock</method><data>" + message + "</data><difficulty>" + difficulty + "</difficulty></newfile>";
                long starttime = System.currentTimeMillis();
                xmLmethod(dataXML); // sending data using a single method
                long endtime = System.currentTimeMillis();
                System.out.println("Total Execution Time to add this block is " + (endtime - starttime) + " milliseconds");
            }
            if (input == 2) {
                long starttime = System.currentTimeMillis();
                System.out.println("Verifying");

                String dataXML = "<newfile><method>verify</method></newfile>";
                System.out.println("Chain Verification: " + xmLmethod(dataXML)); // sending data using a single method
                long endtime = System.currentTimeMillis();
                System.out.println("Total Execution Time to verify this Chain is " + (endtime - starttime) + " milliseconds");
            }
            if (input == 3) {
                String dataXML = "<newfile><method>view</method></newfile>";
                System.out.println(xmLmethod(dataXML)); // sending data using a single method
            }
            if (input == 4) {
                flag = false; //exit
            }
        }

    }
    // XML method to take the data and call th epertaining method on the server side

    private static String xmLmethod(java.lang.String xmldata) throws NoSuchAlgorithmException_Exception, SAXException_Exception, IOException_Exception, ParserConfigurationException_Exception {
        task1.server.BlockChain_Service service = new task1.server.BlockChain_Service();
        task1.server.BlockChain port = service.getBlockChainPort();
        return port.xmLmethod(xmldata);
    }

}
