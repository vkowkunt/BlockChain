/*
 * Block chain server using XML string via SOAP
 */
package task1.server;

import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author venky
 */
@WebService(serviceName = "BlockChain")
public class BlockChain {

    public static List<Block> Myblock = new ArrayList<Block>();
    static String ChainHash;
    static int i;
    static String blockchainJson = "";
    java.util.Date today = new java.util.Date();
    java.sql.Timestamp ts1 = new java.sql.Timestamp(today.getTime());
    long tsTime1 = ts1.getTime();

    /**
     * add block operation
     */
    @WebMethod(operationName = "addBlock")
    public String addBlock(@WebParam(name = "data") String data, @WebParam(name = "difficulty") int difficulty) throws NoSuchAlgorithmException {

        Block B;
        String wrong = "worked";

        BigInteger e = new BigInteger("65537");
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        System.out.println(data);
        String[] splitstring = data.split("#");
        String msg = splitstring[0];
        String hashmsg = splitstring[1];
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(msg.getBytes(StandardCharsets.UTF_8));
        byte[] hash1 = new byte[hash.length + 1];
        hash1[0] = 0;
        System.arraycopy(hash, 0, hash1, 1, hash.length);
        BigInteger k = new BigInteger(hashmsg);
        BigInteger Decryptmsg = k.modPow(e, n);
        BigInteger hashed = new BigInteger(hash1);
        if (!hashed.equals(Decryptmsg)) {
            wrong = "signature invalid";
            System.out.println(wrong);
        } else {
            if (!Myblock.isEmpty()) {
                int index = Myblock.size();
                System.out.println("working");
                B = new Block(index, tsTime1, data, difficulty);
                Myblock.add(B);
                Myblock.get(B.getIndex()).proofOfWork(B.getDifficulty());
                ChainHash = Myblock.get(Myblock.size() - 1).calculateHash();

                blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
            }
        }

        return wrong;

    }

    /**
     * verify chain
     */
    @WebMethod(operationName = "isChainValid")
    public boolean isChainValid() {

        Block currentBlock;
        Block previousBlock;

        //loop through blockchain to check hashes:
        for (int i = 1; i < Myblock.size(); i++) {
            currentBlock = Myblock.get(i);
            previousBlock = Myblock.get(i - 1);
            String hash = currentBlock.calculateHash();
            String target = new String(new char[currentBlock.difficulty]).replace('\0', '0'); //Create a string with difficulty * "0" 
            if (!hash.substring(0, currentBlock.difficulty).equals(target)) {
                System.out.println("The Chain is not valid");
                System.out.println("The node at " + currentBlock.index + " does not have " + target);
                return false;
            }
        }
        System.out.println("The Chain is valid");
        return true;
    }

    /**
     * view the chain
     */
    @WebMethod(operationName = "viewChain")
    public String viewChain() {

        //TODO write your implementation code here:
        return "{Chain:" + blockchainJson + " ChainHash:" + ChainHash + "";
    }

    /**
     * genesis block initialized
     */
    @WebMethod(operationName = "zeroBlock")
    @Oneway
    public void zeroBlock() {
        Block B = new Block(0, tsTime1, "Genesis", 2);
        ChainHash = B.calculateHash();
        Myblock.add(B);
        Myblock.get(B.getIndex()).proofOfWork(2);
        blockchainJson = new GsonBuilder().setPrettyPrinting().create().toJson(Myblock);
    }

    /**
     * Single XML method that calls required method based on the input string
     */
    @WebMethod(operationName = "xmLmethod")
    public String xmLmethod(@WebParam(name = "xmldata") String xmldata) throws ParserConfigurationException, NoSuchAlgorithmException, SAXException, IOException {
        //TODO write your implementation code here:
        if (Myblock.isEmpty()) {
            zeroBlock();
        }
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        Document sensorMessage = null;
        builder = factory.newDocumentBuilder();

        sensorMessage = builder.parse(new InputSource(new StringReader(xmldata)));
        sensorMessage.getDocumentElement().normalize();
        System.out.println("Root element :" + sensorMessage.getDocumentElement().getNodeName());
        String newfile = sensorMessage.getElementsByTagName("newfile").item(0).getTextContent();
        String method = sensorMessage.getElementsByTagName("method").item(0).getTextContent();

        switch (method) {
            case "addblock":
                String data = sensorMessage.getElementsByTagName("data").item(0).getTextContent();
                String difficulty = sensorMessage.getElementsByTagName("difficulty").item(0).getTextContent();
                addBlock(data, Integer.parseInt(difficulty));
                break;
            case "verify":
                return String.valueOf(isChainValid());
            case "view":
                return viewChain();
            default:
                break;
        }
        return null;

    }

}
